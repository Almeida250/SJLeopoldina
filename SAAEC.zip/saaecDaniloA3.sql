CREATE DATABASE saaecJava;
USE saaecJava;
CREATE TABLE funcionario(
	id_funcionario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_funcionario VARCHAR(45) NOT NULL,
    senha_funcionario VARCHAR(45) NOT NULL
);

CREATE TABLE paciente(
	id_paciente INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_paciente VARCHAR(45) NOT NULL,
    cpf_paciente VARCHAR(45) NOT NULL,
    rg_paciente VARCHAR(45) NOT NULL,
	tel_paciente VARCHAR(45) NOT NULL,
    end_paciente  VARCHAR(45) NOT NULL,
    dificuldade_paciente VARCHAR(100) NOT NULL
);

SELECT * FROM paciente;

INSERT INTO funcionario (nome_funcionario, senha_funcionario) VALUES ("admin","admin");
INSERT INTO paciente (nome_paciente, cpf_paciente, rg_paciente, tel_paciente, end_paciente, dificuldade_paciente)
VALUES ('Maria Silva', '123.456.789-00', '10.234.567', '(11) 98765-4321', 'Rua das Flores, 123', 'Mobilidade Reduzida');
INSERT INTO paciente (nome_paciente, cpf_paciente, rg_paciente, tel_paciente, end_paciente, dificuldade_paciente)
VALUES ('João Souza', '987.654.321-00', 'SP-87.654.321', '(11) 91234-5678', 'Avenida B, 456, São Paulo, SP', 'Mobilidade reduzida');
INSERT INTO paciente (nome_paciente, cpf_paciente, rg_paciente, tel_paciente, end_paciente, dificuldade_paciente)
VALUES ('Ana Costa', '111.222.333-44', 'RJ-12.345.678', '(21) 99876-5432', 'Rua C, 789, Rio de Janeiro, RJ', 'Autismo');
INSERT INTO paciente (nome_paciente, cpf_paciente, rg_paciente, tel_paciente, end_paciente, dificuldade_paciente)
VALUES ('Carlos Lima', '555.666.777-88', 'MG-98.765.432', '(31) 98765-1234', 'Praça D, 101, Belo Horizonte, MG', 'Cego');
INSERT INTO paciente (nome_paciente, cpf_paciente, rg_paciente, tel_paciente, end_paciente, dificuldade_paciente)
VALUES ('Beatriz Santos', '999.888.777-66', 'RS-12.987.654', '(51) 91234-5678', 'Rua E, 202, Porto Alegre, RS', 'Alzheimer')
