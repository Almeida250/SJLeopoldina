package com.mycompany.saaec;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
    public boolean existe ( Funcionario funcionario) throws Exception{
        String sql = "SELECT * FROM funcionario WHERE nome_funcionario = ? AND senha_funcionario = ?";
            try (Connection conn = ConexaoBD.obtemConexao();
                 PreparedStatement ps = conn.prepareStatement(sql)){
                    ps.setString(1, funcionario.getNome());
                    ps.setString(2, funcionario.getSenha());
                    try (ResultSet rs = ps.executeQuery()){
                        return rs.next();
                    }
            }
    }
    
    public void inserir (Paciente paciente) throws Exception{
        String sql = "INSERT INTO paciente (nome_paciente,cpf_paciente,rg_paciente,tel_paciente,end_paciente,dificuldade_paciente) values (?,?,?,?,?,?) ";
        try (Connection conn = ConexaoBD.obtemConexao();
                PreparedStatement ps = conn.prepareStatement(sql)){
                ps.setString(1, paciente.getNome());
                ps.setString(2, paciente.getCpf());
                ps.setString(3, paciente.getRg());
                ps.setString(4, paciente.getTel());
                ps.setString(5, paciente.getEnd());
                ps.setString(6, paciente.getDificuldade());
                ps.execute();
        }
    }
    
    public void atualizar (Paciente paciente) throws Exception{
        String sql = "UPDATE paciente SET nome_paciente = ?, cpf_paciente = ?, rg_paciente = ?, tel_paciente = ?, "
       + "end_paciente = ?, dificuldade_paciente = ? WHERE id_paciente = ?";
        try (Connection conn = ConexaoBD.obtemConexao();
                 PreparedStatement ps = conn.prepareStatement(sql)){
                    ps.setString(1, paciente.getNome());
                    ps.setString(2, paciente.getCpf());
                    ps.setString(3, paciente.getRg());
                    ps.setString(4, paciente.getTel());
                    ps.setString(5, paciente.getEnd());
                    ps.setString(6, paciente.getDificuldade());
                    ps.setInt(7, paciente.getId());
                    ps.execute();
        }
    }
    
    public void excluir (Paciente paciente) throws Exception{
        String sql = "DELETE FROM paciente WHERE id_paciente=?";
        try (Connection conn = ConexaoBD.obtemConexao();
                 PreparedStatement ps = conn.prepareStatement(sql)){
                    ps.setInt(1, paciente.getId());
                    ps.execute();
        }
    }
}
