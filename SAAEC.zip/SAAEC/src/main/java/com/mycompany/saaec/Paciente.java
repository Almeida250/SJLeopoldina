package com.mycompany.saaec;

public class Paciente {
    private int id;
    private String nome;
    private String cpf;
    private String rg;
    private String tel;
    private String end;
    private String dificuldade;

    public Paciente(int id, String nome, String cpf, String rg, String tel, String end, String dificuldade) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.tel = tel;
        this.end = end;
        this.dificuldade = dificuldade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getDificuldade() {
        return dificuldade;
    }

    public void setDificuldade(String deficiencia) {
        this.dificuldade = deficiencia;
    }
    

}
